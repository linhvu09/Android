import React, { useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';

interface WeatherData {
  city: string;
  country: string;
  temperature: number;
  windSpeed: number;
  unit: string;
  windUnit: string;
}

export default function HomeScreen() {
  const [city, setCity] = useState<string>('');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const getCoordinates = async (cityName: string) => {
    const response = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cityName)}&count=1&language=vi&format=json`
    );
    const data = await response.json();
    
    if (!data.results || data.results.length === 0) {
      throw new Error('Không tìm thấy thành phố');
    }
    
    return {
      lat: data.results[0].latitude,
      lon: data.results[0].longitude,
      name: data.results[0].name,
      country: data.results[0].country
    };
  };

  const getWeather = async (lat: number, lon: number) => {
    const response = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,wind_speed_10m&timezone=auto`
    );
    const data = await response.json();
    return data;
  };

  const handleSearch = async () => {
    if (!city.trim()) {
      setError('Vui lòng nhập tên thành phố');
      setWeather(null);
      return;
    }

    setError('');
    setLoading(true);
    setWeather(null);

    try {
      const coords = await getCoordinates(city.trim());
      const weatherData = await getWeather(coords.lat, coords.lon);
      
      setWeather({
        city: coords.name,
        country: coords.country,
        temperature: weatherData.current.temperature_2m,
        windSpeed: weatherData.current.wind_speed_10m,
        unit: weatherData.current_units.temperature_2m,
        windUnit: weatherData.current_units.wind_speed_10m
      });
    } catch (err: any) {
      setError(err.message || 'Không thể lấy thông tin thời tiết');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>🌤️ App Thời Tiết</Text>
        
        <TextInput
          style={styles.input}
          placeholder="Nhập tên thành phố..."
          value={city}
          onChangeText={setCity}
          onSubmitEditing={handleSearch}
        />

        <TouchableOpacity 
          style={styles.button}
          onPress={handleSearch}
          disabled={loading}
        >
          <Text style={styles.buttonText}>
            {loading ? 'Đang tải...' : 'Xem thời tiết'}
          </Text>
        </TouchableOpacity>

        {error ? (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>⚠️ {error}</Text>
          </View>
        ) : null}

        {loading && (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#4A90E2" />
            <Text style={styles.loadingText}>Đang tải...</Text>
          </View>
        )}

        {weather && !loading && (
          <View style={styles.weatherContainer}>
            <Text style={styles.cityName}>
              {weather.city}, {weather.country}
            </Text>
            
            <View style={styles.weatherInfo}>
              <View style={styles.infoCard}>
                <Text style={styles.infoLabel}>🌡️ Nhiệt độ</Text>
                <Text style={styles.infoValue}>
                  {weather.temperature}{weather.unit}
                </Text>
              </View>

              <View style={styles.infoCard}>
                <Text style={styles.infoLabel}>💨 Tốc độ gió</Text>
                <Text style={styles.infoValue}>
                  {weather.windSpeed} {weather.windUnit}
                </Text>
              </View>
            </View>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#E8F4F8',
    padding: 20,
    justifyContent: 'center',
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2C3E50',
    textAlign: 'center',
    marginBottom: 24,
  },
  input: {
    backgroundColor: '#F5F7FA',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#E0E6ED',
    marginBottom: 16,
  },
  button: {
    backgroundColor: '#4A90E2',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 16,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  errorContainer: {
    backgroundColor: '#FFE5E5',
    borderRadius: 12,
    padding: 16,
    marginTop: 8,
  },
  errorText: {
    color: '#D32F2F',
    fontSize: 14,
    textAlign: 'center',
  },
  loadingContainer: {
    alignItems: 'center',
    marginTop: 24,
  },
  loadingText: {
    color: '#4A90E2',
    fontSize: 16,
    marginTop: 12,
  },
  weatherContainer: {
    marginTop: 24,
    backgroundColor: '#F8FBFF',
    borderRadius: 16,
    padding: 20,
  },
  cityName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#2C3E50',
    textAlign: 'center',
    marginBottom: 20,
  },
  weatherInfo: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  infoCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  infoLabel: {
    fontSize: 14,
    color: '#7F8C8D',
    marginBottom: 8,
  },
  infoValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4A90E2',
  },
 });
